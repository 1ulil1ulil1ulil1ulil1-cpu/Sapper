package com.example.sapper;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private WebView web;
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#101216"));
        getWindow().setNavigationBarColor(Color.parseColor("#101216"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#101216"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override
    public void onBackPressed() { finish(); }
}
